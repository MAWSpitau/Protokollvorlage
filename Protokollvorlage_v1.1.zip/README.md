# Protokollvorlage

Eine einfache Protokollvorlage, die gerade ausgedruckt viel Sinn macht.

Eine Beschreibung der Vorlage gibt es hier:

http://herrspitau.de/2017/03/01/protokollvorlage-fuer-konferenzen-einfach-und-effizient/

# Änderungen
* 2017-03-04 - Excel-Vorlage (xml) exportiert.
* 2106-11-11 - Excel-Vorlage exportiert.
* 2016-11-10 - Die Informationen im Footer sind verbessert worden. Link zur Seite ist hinzugefügt und das Änderungsdatum ändert sich automatisch.
